Test Project
=============

This is a test package as part of some work on library security.  More information available `here <https://github.com/raesene/test_libs>`